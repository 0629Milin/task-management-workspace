import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class ToastrCustomService {

  constructor(private toastr: ToastrService) {}

  // Success message
  showSuccess(message: string, title: string = 'Success') {
    this.toastr.success(message, title, {
      timeOut: 3000, // Duration of toast
      positionClass: 'toast-top-right',
      closeButton: true
    });
  }

  // Error message
  showError(message: string, title: string = 'Error') {
    this.toastr.error(message, title, {
      timeOut: 3000,
      positionClass: 'toast-top-right',
      closeButton: true
    });
  }

  // Info message
  showInfo(message: string, title: string = 'Information') {
    this.toastr.info(message, title, {
      timeOut: 3000,
      positionClass: 'toast-top-right',
      closeButton: true
    });
  }

  // Warning message
  showWarning(message: string, title: string = 'Warning') {
    this.toastr.warning(message, title, {
      timeOut: 3000,
      positionClass: 'toast-top-right',
      closeButton: true
    });
  }
}
