import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoaderService } from './loader.service'; // Import the loader service

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private apiUrl = 'https://cqtdvjhn-44356.inc1.devtunnels.ms/api';

  constructor(private http: HttpClient, private loaderService: LoaderService) { }

  // HTTP GET Request - Generic method
  get<T>(endpoint: string, params?: { [key: string]: string | number | boolean }): Observable<T> {
    const url = `${this.apiUrl}/${endpoint}`;
    const httpParams = this.createHttpParams(params);

    // Show the loader before the API call
    this.loaderService.showLoader();

    // Return the GET request, but hide the loader once completed
    return new Observable<T>(observer => {
      this.http.get<T>(url, { params: httpParams })
        .subscribe(
          response => {
            this.loaderService.hideLoader();  // Hide loader on success
            observer.next(response);
            observer.complete();
          },
          error => {
            this.loaderService.hideLoader();  // Hide loader on error
            observer.error(error);
          }
        );
    });
  }

  // HTTP POST Request - Generic method
  post<T, TData>(endpoint: string, data: TData): Observable<T> {
    const url = `${this.apiUrl}/${endpoint}`;

    // Show the loader before the API call
    this.loaderService.showLoader();

    // Return the POST request, but hide the loader once completed
    return new Observable<T>(observer => {
      this.http.post<T>(url, data)
        .subscribe(
          response => {
            this.loaderService.hideLoader();  // Hide loader on success
            observer.next(response);
            observer.complete();
          },
          error => {
            this.loaderService.hideLoader();  // Hide loader on error
            observer.error(error);
          }
        );
    });
  }

  // HTTP PUT Request - Generic method
  put<T, TData>(endpoint: string, data: TData): Observable<T> {
    const url = `${this.apiUrl}/${endpoint}`;

    // Show the loader before the API call
    this.loaderService.showLoader();

    // Return the PUT request, but hide the loader once completed
    return new Observable<T>(observer => {
      this.http.put<T>(url, data)
        .subscribe(
          response => {
            this.loaderService.hideLoader();  // Hide loader on success
            observer.next(response);
            observer.complete();
          },
          error => {
            this.loaderService.hideLoader();  // Hide loader on error
            observer.error(error);
          }
        );
    });
  }

  // HTTP DELETE Request - Generic method
  delete<T>(endpoint: string): Observable<T> {
    const url = `${this.apiUrl}/${endpoint}`;

    // Show the loader before the API call
    this.loaderService.showLoader();

    // Return the DELETE request, but hide the loader once completed
    return new Observable<T>(observer => {
      this.http.delete<T>(url)
        .subscribe(
          response => {
            this.loaderService.hideLoader();  // Hide loader on success
            observer.next(response);
            observer.complete();
          },
          error => {
            this.loaderService.hideLoader();  // Hide loader on error
            observer.error(error);
          }
        );
    });
  }

  // Helper method to create HttpParams from an object
  private createHttpParams(params?: { [key: string]: string | number | boolean }): HttpParams {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
          httpParams = httpParams.set(key, params[key].toString());
        }
      });
    }
    return httpParams;
  }
}
