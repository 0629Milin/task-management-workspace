import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {

  private isLoadingSubject = new BehaviorSubject<boolean>(false);
  public isLoading$ = this.isLoadingSubject.asObservable();

  constructor() { }

  // Set loading state to true
  showLoader() {
    this.isLoadingSubject.next(true);
  }

  // Set loading state to false
  hideLoader() {
    this.isLoadingSubject.next(false);
  }
}
