import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { ApiService } from './api.service';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';
import { Logincredentials } from '../models/logincredentials.model';
import { isPlatformBrowser } from '@angular/common';
import { AddToCartModel } from '../models/addtocart.model';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  
  private _isAuthenticated = new BehaviorSubject<boolean>(false);
  private isBrowser: boolean;
  isLoggedIn$ = this._isAuthenticated.asObservable();

  constructor(
    private apiService: ApiService,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);

    if (this.isBrowser) {
      const token = localStorage.getItem('jwt_token');
      if (token) {
        this._isAuthenticated.next(true);
      }
    }
  }

  get isAuthenticated$(): Observable<boolean> {
    return this._isAuthenticated.asObservable();
  }

  addToCart(addToCart: AddToCartModel): Observable<any> {
    return this.apiService.post('product/addToCart', addToCart);
  }

  getCartDetails(): Observable<any> {
    return this.apiService.get('product/getCartDetails');
  }

  setToken(token: string): void {
    if (this.isBrowser) {
      localStorage.setItem('jwt_token', token);
      this._isAuthenticated.next(true);
    }
  }

}
