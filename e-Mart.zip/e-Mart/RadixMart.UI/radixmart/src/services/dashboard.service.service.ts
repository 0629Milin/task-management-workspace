import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { ApiService } from './api.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { Category } from '../models/category.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  
  private _categories = new BehaviorSubject<Category[]>([]);
  private isBrowser: boolean;

  constructor(
    private apiService: ApiService,
    @Inject(PLATFORM_ID) private platformId: object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);

    if (this.isBrowser) {
      this.loadCategories();
    }
  }

  get categories$(): Observable<Category[]> {
    return this._categories.asObservable();
  }

  loadCategories(): void {
    if (this.isBrowser) {
      this.apiService.get<Category[]>('product').subscribe(
        (data) => {
          this._categories.next(data);
        },
        (error) => {
          console.error('Error fetching categories:', error);
        }
      );
    }
  }

  refreshCategories(): void {
    this.loadCategories();
  }
}
