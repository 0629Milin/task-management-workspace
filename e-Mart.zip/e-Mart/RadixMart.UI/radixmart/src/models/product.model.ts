export interface Product {
    id: number;
    name: string;
    price: number;
    filepath: string;
    description?: string; // Optional field
    stock?: number; // Optional stock quantity
  }
  