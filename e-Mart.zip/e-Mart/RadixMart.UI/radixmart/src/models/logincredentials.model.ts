export interface Logincredentials {
    userName: string;
    password: string;
  }