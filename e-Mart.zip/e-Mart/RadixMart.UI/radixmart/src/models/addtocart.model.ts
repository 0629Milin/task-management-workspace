export interface AddToCartModel {
  userId: number;
  productId: number;
  quantity: number;
  isBuy: boolean;
  productName: string;
  productDescription: string;
  productFilepath: string;
}
