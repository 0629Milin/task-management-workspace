import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { LoaderService } from '../services/loader.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner'
import { MatToolbarModule } from '@angular/material/toolbar'
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';
import { ToastrCustomService } from '../services/toastr.service';
import { NavbarComponent } from '../pages/shared/navbar/navbar.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, MatProgressSpinnerModule, CommonModule, NavbarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'radixmart';
  isLoading: boolean = false;
  userFullName = "John Doe";
  isLoggedIn: boolean = false;

  constructor(private authService: AuthService, private router: Router, private toastrService: ToastrCustomService, private loaderService: LoaderService) {
    
  }
  

  ngOnInit():void{
    this.isLoggedIn = this.authService.checkAuthentication();

    this.authService.isLoggedIn$.subscribe((status) => {
      this.isLoggedIn = status;
    });

this.loaderService.isLoading$.subscribe(isLoading => {
  this.isLoading = isLoading;
});
  }

  // logout(): void {
  //   this.authService.logout();
  //   this.router.navigate(['/login']);
  //   this.toastrService.showSuccess("Logged out successfully!");
  // }
}
