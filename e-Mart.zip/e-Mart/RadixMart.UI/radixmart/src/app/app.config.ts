import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { BrowserModule, provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { JwtModule } from '@auth0/angular-jwt';

import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { provideHttpClient, HTTP_INTERCEPTORS, withInterceptorsFromDi  } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AuthInterceptorService } from './auth-interceptor.service';

export const appConfig: ApplicationConfig = {
  providers: [
  provideHttpClient(withInterceptorsFromDi()),
  ReactiveFormsModule,
  FormsModule,
  CommonModule,
  JwtModule,
  BrowserModule, 
  BrowserAnimationsModule,
  {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptorService,
    multi: true
  },
  importProvidersFrom(
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ),
  provideRouter(routes), 
  provideZoneChangeDetection({ eventCoalescing: true }), 
  provideClientHydration(withEventReplay())]
};
