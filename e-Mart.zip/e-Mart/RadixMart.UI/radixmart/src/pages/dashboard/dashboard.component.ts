import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ToastrCustomService } from '../../services/toastr.service';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { CommonModule } from '@angular/common';
import { DashboardService } from '../../services/dashboard.service.service';
import { Category } from '../../models/category.model';
import { CommonService } from '../../services/common.service';
import { AddToCartModel } from '../../models/addtocart.model';

@Component({
  selector: 'app-dashboard',
  imports: [
    CommonModule, MatToolbarModule, MatGridListModule, MatCardModule, MatButtonModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  title = 'Product Dashboard';

  categories: Category[] = [];
  addtocart: AddToCartModel[] = [];
  constructor(private dashboardService: DashboardService,private commonService: CommonService,private toastrService: ToastrCustomService) {}

  ngOnInit(): void {
    this.dashboardService.categories$.subscribe(
      (data) => {
        this.categories = data;
        console.log(this.categories);
      }
    );
  }
  addToCart(product :any): void {
    debugger
    var selectedproduct = this.categories
    .flatMap(category => 
      category.products
        .filter(prod => prod.name.includes(product.name))
        .map(prod => ({
          categoryId: category.id,
          categoryName: category.name,
          productId: prod.id,
          productName: prod.name
        }))
    )[0] || null; 
  
  const cartItem: AddToCartModel = {
      userId: product.userId,
      productId: selectedproduct.productId,
      quantity: 1,
      isBuy: false,
      productName: selectedproduct.productName,
      productDescription: "",
      productFilepath: "",
    };

    this.commonService.addToCart(cartItem).subscribe({
      next: (response) => { 
        this.toastrService.showSuccess(response.message); // Show API response in the toaster
      },
      error: (error) => {
        console.error('Error adding item to cart:', error);
        this.toastrService.showError("Failed to add item to cart"); // Show error message
      }
    });
    
  }
 // Increase Quantity
  increaseQuantity(product: any): void {
    product.quantity = (product.quantity || 1) + 1;
  }

  // Decrease Quantity
  decreaseQuantity(product: any): void {
    if (product.quantity && product.quantity > 1) {
      product.quantity--;
    }
  }


  refreshCategories(): void {
    this.dashboardService.refreshCategories();
  }
}
