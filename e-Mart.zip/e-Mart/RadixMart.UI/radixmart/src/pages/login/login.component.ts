import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { FormsModule, NgForm } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { Logincredentials } from '../../models/logincredentials.model';
import { ToastrCustomService } from '../../services/toastr.service';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'app-login',
  imports: [FormsModule, MatButtonModule, MatInputModule, MatCardModule, CommonModule, MatIcon],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  loginCredentials: Logincredentials = {userName: '', password: ''};
  hidePassword = true;
  constructor(private authService: AuthService, private router: Router, private toastrService: ToastrCustomService) {}

  ngOnInit(){
    if (this.authService.checkAuthentication()) {
      this.router.navigate(['/dashboard']);
      return;
    }
  }

  async onSubmit(loginForm: NgForm): Promise<void> {
    try {
      if (loginForm.invalid) {
        return;
      }
      const response = this.authService.login(this.loginCredentials).subscribe({
        next: (response) => {
          if (response && response.status == true) {
            this.authService.setToken(response.data);
            this.router.navigate(['/dashboard']);
            this.toastrService.showSuccess(response.responseMessage);
          }
          else{
            this.toastrService.showError(response.responseMessage);
          }
        },
        error: (error) => {
          console.error('Login failed', error);
          this.toastrService.showError(error.error.responseMessage);
        }
      });
    } catch (error) {
      console.error('Login failed', error);
      this.toastrService.showError("Something went wrong!")
    }
  }
}
