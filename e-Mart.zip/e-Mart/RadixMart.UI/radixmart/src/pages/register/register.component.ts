import { Component } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormsModule, NgForm } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { User } from '../../models/user.model';
import { ToastrCustomService } from '../../services/toastr.service';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'app-register',
  imports: [FormsModule, MatButtonModule, MatInputModule, MatCardModule, CommonModule, MatIcon],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {
  user: User = { 
    userName: '', 
    email: '', 
    password: '',
    firstName: '',
    lastName: '',
    address:''
  };

  hidePassword = true;

  constructor(private authService: AuthService, private router: Router, private toastrService: ToastrCustomService) {}

  async onSubmit(registerForm: NgForm): Promise<void> {
    try {
      if (registerForm.invalid) {
        return;
      }
      // const response = await firstValueFrom(this.authService.register(this.user));
      // console.log(response);
      // if (response && response.status == true) {
      //   console.log('Registration successful');
      //   this.router.navigate(['/login']);
      //   this.toastrService.showSuccess(response.responseMessage);
      // }
      // else{
      //   this.toastrService.showError(response.responseMessage);
      // }

      // Using subscribe for API call
    this.authService.register(this.user).subscribe({
      next: (response) => {
        if (response && response.status == true) {
          console.log('Registration successful');
          this.router.navigate(['/login']);
          this.toastrService.showSuccess(response.responseMessage);
        }
        else{
          this.toastrService.showError(response.responseMessage);
        }
      },
      error: (error) => {
        console.error('Registration failed:', error);
        this.toastrService.showError(error.error.responseMessage);
      }
    });

    } catch (error) {
      console.error('Registration failed', error);
      this.toastrService.showError("Something went wrong!");
    }

    

  }
}

