import { Component } from '@angular/core';
import { AddToCartModel } from '../../models/addtocart.model';
import { CommonService } from '../../services/common.service';
import { ToastrCustomService } from '../../services/toastr.service';

@Component({
  selector: 'app-cart',
  imports: [],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.scss'
})
export class CartComponent {
  addtocart: AddToCartModel[] = [];
    constructor(private commonService: CommonService,private toastrService: ToastrCustomService) {}
    
    products = [
      {
        image: 'https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-shopping-carts/img1.webp',
        name: 'Basic T-shirt',
        size: 'M',
        color: 'Grey',
        price: 499.00,
        quantity: 2
      },
      {
        image: 'https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-shopping-carts/img2.webp',
        name: 'Casual Shirt',
        size: 'L',
        color: 'Blue',
        price: 699.00,
        quantity: 1
      }
    ];
    ngOnInit(): void {
      debugger
      this.commonService.getCartDetails().subscribe({
        next: (response) => { 
          this.addtocart = response; 
        },
        error: (error) => {
          console.error('Error adding item to cart:', error);
          this.toastrService.showError("Failed to add item to cart"); // Show error message
        }
      });
    }
}
