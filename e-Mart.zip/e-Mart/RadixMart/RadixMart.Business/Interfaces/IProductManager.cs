﻿using RadixMart.Models.ResponseModel;
using RadixMart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RadixMart.Models.ViewModel;

namespace RadixMart.Business.Interfaces
{
   public interface IProductManager
    {
        Task<List<CategoryProductModel>> GetProducts();
        Task<string> AddToCart(AddToCartModel model);
    }
}
