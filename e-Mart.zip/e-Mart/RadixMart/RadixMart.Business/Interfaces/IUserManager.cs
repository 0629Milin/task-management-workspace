﻿using RadixMart.Models;
using RadixMart.Models.ResponseModel;

namespace RadixMart.Business
{
    public interface IUserManager
    {
        Task<UserRegisterModel> RegisterUser(RegisterUser user);
        Task<UserRegisterModel> AuthenticateUser(LoginUser request);
    }
}
