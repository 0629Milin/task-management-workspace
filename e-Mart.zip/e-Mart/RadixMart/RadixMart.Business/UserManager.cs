﻿using RadixMart.DataAccess.Models;
using RadixMart.DataAccess;
using RadixMart.Models;
using System.Security.Cryptography;
using System.Text;
using RadixMart.Business.Services;
using Microsoft.Extensions.Configuration;
using RadixMart.Models.ResponseModel;

namespace RadixMart.Business
{
    public class UserManager : IUserManager
    {
        private readonly IUserRepository _userRepository;
        private readonly JwtTokenGenerator _tokenGenerator;
        private readonly IConfiguration _config;
        public string _encryptionKey;

        public UserManager(IUserRepository userRepository, JwtTokenGenerator tokenGenerator, IConfiguration config)
        {
            _userRepository = userRepository;
            _tokenGenerator = tokenGenerator;
            _config = config;
            _encryptionKey = _config["EncryptionKey"] ?? string.Empty;
        }

        public async Task<UserRegisterModel> RegisterUser(RegisterUser user)
        {
            UserRegisterModel userRegisterModel = new UserRegisterModel();

            var existingUser = await _userRepository.GetUserDetailsAsync(user.Username);
            if (existingUser != null)
            {
                userRegisterModel.ResponseMessage = "UserName is already Exist.Please try another UserName.";
                userRegisterModel.Status = false;
                return userRegisterModel;
            }

            var newUser = new DataAccess.User
            {
                Username = user.Username,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Address = user.Address,
                Email = user.Email,
                Password = Encrypt(user.Password),
                CreatedAt = DateTime.Now
            };

            await _userRepository.AddUserAsync(newUser);
            userRegisterModel.ResponseMessage = "User Registered Successfully.";
            userRegisterModel.Status = true;
            return userRegisterModel;
        }

        public async Task<UserRegisterModel> AuthenticateUser(LoginUser request)
        {
            UserRegisterModel userRegisterModel = new UserRegisterModel();
            var user = await _userRepository.GetUserDetailsAsync(request.Username);
            var password = "";
            var passwordold = "";
            if (user != null)
            {
                password = Decrypt(user.Password);
                passwordold = (request.Password);
            }
            if (user == null || passwordold != password)
            {
                userRegisterModel.ResponseMessage = "Login failed: Invalid credentials.";
                userRegisterModel.Status = false;
                return userRegisterModel;
            }

            var token = _tokenGenerator.GenerateToken(Convert.ToString(user.Id), user.Email);
            userRegisterModel.ResponseMessage = "Login Successfully.";
            userRegisterModel.Status = true;
            userRegisterModel.Data = token;
            return userRegisterModel;
        }

        private string Encrypt(string plainText)
        {
            byte[] keyBytes = Encoding.UTF8.GetBytes(_encryptionKey);
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.GenerateIV();
                byte[] iv = aesAlg.IV;

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, aesAlg.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                    }

                    byte[] encryptedData = ms.ToArray();
                    return Convert.ToBase64String(iv) + ":" + Convert.ToBase64String(encryptedData);
                }
            }
        }

        private string Decrypt(string cipherText)
        {
            string[] parts = cipherText.Split(':');
            if (parts.Length != 2)
                throw new ArgumentException("Invalid encrypted text format.");

            byte[] iv = Convert.FromBase64String(parts[0]);
            byte[] encryptedData = Convert.FromBase64String(parts[1]);

            byte[] keyBytes = Encoding.UTF8.GetBytes(_encryptionKey);

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.IV = iv;

                using (MemoryStream ms = new MemoryStream(encryptedData))
                {
                    using (CryptoStream cs = new CryptoStream(ms, aesAlg.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}
