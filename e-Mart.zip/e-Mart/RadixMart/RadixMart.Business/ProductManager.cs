﻿using Microsoft.Extensions.Configuration;
using RadixMart.Business.Interfaces;
using RadixMart.Models.ResponseModel;
using RadixMart.DataAccess.Repositories.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using RadixMart.Models.ViewModel;

namespace RadixMart.Business
{
    public class ProductManager : IProductManager
    {
        private readonly IProductRepository _productRepository;
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _config;

        private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(1);
        private const string CacheKey = "ProductList";

        public string _encryptionKey;

        public ProductManager(IProductRepository productRepository, IMemoryCache cache, IConfiguration config)
        {
            _productRepository = productRepository;
            _cache = cache;
            _config = config;
            _encryptionKey = _config["EncryptionKey"] ?? string.Empty;
        }

        public async Task<List<CategoryProductModel>> GetProducts()
        {
            if (!_cache.TryGetValue(CacheKey, out List<CategoryProductModel> products))
            {
                products = await _productRepository.GetProducts();

                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(_cacheDuration);

                _cache.Set(CacheKey, products, cacheOptions);
            }

            return products;
        }

        public async Task<string> AddToCart(AddToCartModel model)
        {
            var rep =await _productRepository.AddToCart(model);
            return rep;
        }

        public async Task<List<AddToCartModel>> GetCartDetails(int userId)
        {
            var rep = await _productRepository.GetCartDetails(userId);
            return rep;
        }
    }
}
