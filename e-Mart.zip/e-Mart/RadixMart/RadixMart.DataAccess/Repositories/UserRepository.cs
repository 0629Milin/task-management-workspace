﻿using Microsoft.EntityFrameworkCore;
using RadixMart.DataAccess.Models;
using RadixMart.Models;
using static System.Net.Mime.MediaTypeNames;

namespace RadixMart.DataAccess
{
    public class UserRepository : IUserRepository
    {
        private readonly RadixMartDbContext _context;

        public UserRepository(RadixMartDbContext context)
        {
            _context = context;
        }

        public async Task AddUserAsync(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
        }

        public async Task<User?> GetUserDetailsAsync(string? username = null)
        {
            return await _context.Users.FirstOrDefaultAsync(x =>
                (username != null && x.Username == username));
        }

        public async Task<User?> ValidateUsername(LoginUser model)
        {

            return await _context.Users.FirstOrDefaultAsync(x => x.Username == model.Username && x.Password == model.Password);
        }
    }
}
