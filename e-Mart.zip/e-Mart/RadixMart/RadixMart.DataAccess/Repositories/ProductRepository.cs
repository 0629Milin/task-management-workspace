﻿using Microsoft.Azure.Documents;
using Microsoft.EntityFrameworkCore;
using RadixMart.DataAccess.Models;
using RadixMart.DataAccess.Repositories.Interfaces;
using RadixMart.Models;
using RadixMart.Models.ResponseModel;
using RadixMart.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadixMart.DataAccess.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly RadixMartDbContext _context;

        public ProductRepository(RadixMartDbContext context)
        {
            _context = context;
        }

        public async Task<List<CategoryProductModel>> GetProducts()
        {
            var products = await _context.Categories.Select(a => new CategoryProductModel
            {
                Id = a.Id,
                Name = a.Name,
                Products = a.Products.Select(x => new ProductModel
                {
                    Id = x.Id,
                    Description = x.Description,
                    Name = x.Name,
                    Price = x.Price,
                    StockQuantity = x.StockQuantity,
                    Filepath = x.Filepath
                }).OrderBy(x => x.Name).ToList()
            }).OrderBy(a => a.Name).ToListAsync();
            return products;
        }

        public async Task<string> AddToCart(AddToCartModel model)
            {
            if (model is null || model.UserId <= 0 || model.ProductId <= 0 || model.Quantity <= 0)
                return "Something went wrong.";

            var existingCartItem = await _context.Carts.Where(c => c.UserId == model.UserId && c.ProductId == model.ProductId).Select(c => c.CartId).FirstOrDefaultAsync();
            var cartItem = await _context.Carts.FindAsync(existingCartItem);
            if (cartItem != null)
            {
                // Update only the necessary fields
                cartItem.Quantity = model.Quantity;
                cartItem.CreatedDate = DateTime.UtcNow;
                _context.Carts.Update(cartItem);
                return "Item updated successfully in to Cart.";
            }
            else
            {
                cartItem = new Cart
                {
                    UserId = model.UserId,
                    ProductId = model.ProductId,
                    Quantity = model.Quantity,
                    CreatedDate = DateTime.UtcNow
                };
                _context.Carts.Add(cartItem);
                await _context.SaveChangesAsync();
                return "Item added to cart successfully.";
            }
        }

        public async Task<List<AddToCartModel>> GetCartDetails(int userId)
        {
            var cartdetails = await (from c in _context.Carts
                                     join p in _context.Products on c.ProductId equals p.Id
                                     where c.UserId == userId && c.IsBuy == false
                                     select new AddToCartModel
                                     {
                                         ProductId = c.ProductId,
                                         Quantity = c.Quantity,
                                         ProductName = p.Name,
                                         ProductDescription = p.Description ?? string.Empty,
                                         ProductFilepath = p.Filepath ?? string.Empty,
                                         UserId = userId
                                     }).ToListAsync();
            return cartdetails;
        }

    }
}
