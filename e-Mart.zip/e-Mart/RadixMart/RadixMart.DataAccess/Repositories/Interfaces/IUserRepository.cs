﻿using RadixMart.DataAccess.Models;
using RadixMart.Models;

namespace RadixMart.DataAccess
{
    public interface IUserRepository
    {
        Task AddUserAsync(User user);
        Task<User?> GetUserDetailsAsync(string? username = null);
        Task<User?> ValidateUsername(LoginUser loginUser);
    }
}
