﻿using RadixMart.Models;
using RadixMart.Models.ResponseModel;
using RadixMart.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadixMart.DataAccess.Repositories.Interfaces
{
    public interface IProductRepository
    {
        Task<List<CategoryProductModel>> GetProducts();
        Task<string> AddToCart(AddToCartModel model);
        Task<List<AddToCartModel>> GetCartDetails(int userId);
    }
}
