﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RadixMart.Models;
using RadixMart.Models.ViewModel;
using RadixMart.Services;
using RadixMart.Services.Interfaces;
using System.Security.Claims;

namespace RadixMart.Controllers
{
    [Authorize]
    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        private readonly ILogger<ProductController> _logger;
        private readonly IProductService _productService;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public ProductController(IProductService productService, ILogger<ProductController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _productService = productService;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            var userid = _httpContextAccessor.HttpContext?.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            _logger.LogInformation("GetProducts is call start");
            try
            {
                var data = await _productService.GetProducts();
                _logger.LogInformation("GetProducts is call end");
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, "Error occurred while processigng GetProducts");
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("addToCart")]
        public async Task<IActionResult> AddToCart(AddToCartModel model)
        {
            _logger.LogInformation("AddToCart call start");
            if (int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out int userId))
            {
                model.UserId = userId;
            }

            try
            {
                var data = await _productService.AddToCart(model);
                _logger.LogInformation("AddToCart call end.");
                return Ok(new { message = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, "Error occurred while processigng AddToCart");
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("getCartDetails")]
        public async Task<IActionResult> GetCartDetails()
        {
            _logger.LogInformation("AddToCart call start");
            int userId = int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out int parsedUserId) ? parsedUserId : 0;
            try
            {
                var data = await _productService.GetCartDetails(userId);
                _logger.LogInformation("AddToCart call end.");
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, "Error occurred while processigng AddToCart");
                return StatusCode(500, ex.Message);
            }
        }
    }
}
