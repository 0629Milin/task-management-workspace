﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using RadixMart.Models;
using RadixMart.Models.ResponseModel;
using RadixMart.Services;

namespace RadixMart.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILogger<UserController> _logger;

        public UserController(IUserService userService, ILogger<UserController> logger)
        {
            _userService = userService;
            _logger = logger;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterUser model)
        {
            _logger.LogInformation("Register API called for Email: {Email}", model.Email);

            try
            {
                var userRegisterModel = await _userService.RegisterUser(model);
                if (!userRegisterModel.Status)
                {
                    _logger.LogWarning("Registration failed: User already exists - Email: {Email}", model.Email);
                    return BadRequest(userRegisterModel);
                }

                _logger.LogInformation("User registered successfully - Email: {Email}", model.Email);
                return Ok(userRegisterModel);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, "Error occurred while registering user - Email: {Email}", model.Email);
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginUser model)
        {
            _logger.LogInformation("Login API called for Email: {Email}", model.Username);
            try
            {
                var userRegisterModel = await _userService.AuthenticateUser(model);

                if (userRegisterModel == null)
                {
                    _logger.LogWarning("Login failed: Invalid credentials - Email: {Email}", model.Username);
                    return BadRequest(userRegisterModel);
                }

                _logger.LogInformation("Login successful - Username: {Username}", model.Username);
                return Ok(userRegisterModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, "Error occurred while logging in - Email: {Email}", model.Username);
                return StatusCode(500, ex.Message);
            }
        }
    }
}
