﻿using RadixMart.Models.ResponseModel;
using RadixMart.Models;
using RadixMart.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RadixMart.Business;
using RadixMart.Models.ViewModel;

namespace RadixMart.Services.Implementations
{
    public class ProductService: IProductService
    {
        private readonly ProductManager _productManager;

        public ProductService(ProductManager productManager)
        {
            _productManager = productManager;
        }

        public async Task<List<CategoryProductModel>> GetProducts()
        {
            return await _productManager.GetProducts();
        }

        public async Task<string> AddToCart(AddToCartModel model)
        {
            return await _productManager.AddToCart(model);
        }

        public async Task<List<AddToCartModel>> GetCartDetails(int userId)
        {
            return await _productManager.GetCartDetails(userId);
        }
    }
}
