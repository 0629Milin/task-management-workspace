﻿using RadixMart.Business;
using RadixMart.Models;
using RadixMart.Models.ResponseModel;

namespace RadixMart.Services
{
    public class UserService : IUserService
    {

        private readonly UserManager _userManager;

        public UserService(UserManager userManager)
        {
            _userManager = userManager;
        }

        public async Task<UserRegisterModel> RegisterUser(RegisterUser user)
        {
            return await _userManager.RegisterUser(user);                       
        }

        public async Task<UserRegisterModel> AuthenticateUser(LoginUser user)
        {
            return await _userManager.AuthenticateUser(user);
        }
    }
}
