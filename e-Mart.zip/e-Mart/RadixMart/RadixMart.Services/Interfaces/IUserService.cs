﻿
using RadixMart.Models;
using RadixMart.Models.ResponseModel;

namespace RadixMart.Services
{
    public interface IUserService
    {
        Task<UserRegisterModel> RegisterUser(RegisterUser user);

        Task<UserRegisterModel> AuthenticateUser(LoginUser user);
    }
}
