﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadixMart.Models.ResponseModel
{
    public class CategoryProductModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public List<ProductModel> Products { get; set; } = new();
    }

    public class ProductModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public string? Filepath { get; set; }
    }
}
