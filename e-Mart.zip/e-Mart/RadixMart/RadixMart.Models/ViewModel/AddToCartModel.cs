﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadixMart.Models.ViewModel
{
   public class AddToCartModel
    {
        public int UserId { get; set; } = 0;
        public int ProductId { get; set; } =0 ;
        public int Quantity { get; set; } =0 ;
        public bool IsBuy { get; set; } = false ;
        public string ProductName { get; set; } = string.Empty ;
        public string ProductDescription { get; set; } = string.Empty ;
        public string ProductFilepath { get; set; } = string.Empty ;
    }
}
