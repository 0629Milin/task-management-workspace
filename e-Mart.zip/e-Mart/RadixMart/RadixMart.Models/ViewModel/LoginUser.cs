﻿namespace RadixMart.Models
{
    public class LoginUser
    {
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
